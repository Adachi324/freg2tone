import './style.css';
import { act, createGame, paused } from './game.ts';
import type { Action, MaterialId, Phase } from './game.ts';
import { createScene } from './scene.ts';
import { Sound } from './audio.ts';

const app = document.querySelector<HTMLDivElement>('#app')!;
app.innerHTML = `
  <main id="world">
    <canvas id="scene" aria-label="花园里的节拍器、三枚音符材料和一座吊桥"></canvas>
    <div class="paper-grain" aria-hidden="true"></div>
    <header class="topbar">
      <div class="brand"><span class="brand-note">♪</span><div>调音花园<small>声音之桥</small></div></div>
      <div class="chapter"><span id="chapter-label">初见 · 声音之桥</span><div class="steps" aria-hidden="true"><i></i><i></i><i></i><i></i></div></div>
      <nav aria-label="体验设置"><button id="music" class="quiet" aria-pressed="false">♪ 声音关</button><button id="paper" class="quiet" aria-pressed="true">纸声开</button><button id="help" class="quiet" hidden>回看</button></nav>
    </header>
    <section id="lesson" class="lesson" aria-labelledby="lesson-title"></section>
    <div id="objects" aria-label="音乐材料">
      <button class="hotspot material" data-material="C" aria-label="选择材料 C"><span>C</span></button>
      <button class="hotspot material" data-material="D" aria-label="选择材料 D"><span>D</span></button>
      <button class="hotspot material" data-material="E" aria-label="选择材料 E"><span>E</span></button>
      <button class="hotspot slot" id="slot" aria-label="靠近机关"><span class="slot-hint">点一下机关 <b>↗</b></span></button>
    </div>
    <footer class="bottom"><p id="feedback" role="status" aria-live="polite"></p><span class="edition">一段小小的声音冒险</span></footer>
    <div id="audio-notice" role="status" hidden></div>
  </main>
  <section id="overlay" role="dialog" aria-modal="true" aria-labelledby="overlay-title" hidden><div class="modal-paper"></div></section>
`;
const $ = <T extends HTMLElement>(selector: string) => document.querySelector<T>(selector)!;
const world = $('#world'), lesson = $('#lesson'), overlay = $('#overlay');
const canvas = $<HTMLCanvasElement>('#scene');
const musicButton = $<HTMLButtonElement>('#music'), paperButton = $<HTMLButtonElement>('#paper');
const helpButton = $<HTMLButtonElement>('#help'), slot = $<HTMLButtonElement>('#slot');
const materials = Array.from(document.querySelectorAll<HTMLButtonElement>('[data-material]'));
const reduced = matchMedia('(prefers-reduced-motion: reduce)');
let game = createGame();
const sound = new Sound();
let scene: ReturnType<typeof createScene> | undefined;
let failure = '';
let phaseTime = 0, totalTime = 0, lastTime = 0;
let demoTime = 0, demoIndex = -1, playingDemo = false;
let pulse: MaterialId | null = null, pulseStart = 0;
let noticeUntil = 0;
let audioRequest = 0, lifecycleEpoch = 0;
let previousPanel = '', previousOverlay = '', returnFocus: HTMLElement | null = null;
const duration: Partial<Record<Phase, number>> = { approach: 0.9, bridge: 1.25, crossing: 2.2 };
const isInteractive = () => !paused(game) && !failure && (game.phase === 'challenge' || (game.phase === 'practice' && !game.practiceDone));
const button = (action: string, text: string, secondary = false) => `<button class="${secondary ? 'secondary' : 'primary'}" data-action="${action}">${text}</button>`;
const explanation = `<p>C、D、E 是三个音的<b>音名</b>，像名字一样，帮我们认出不同的声音。</p><p>点一下材料可以听它的声音。这里的机关需要 <b>C</b>：先选 C，再点机关的圆槽。</p>`;

function notify(text: string) {
  const notice = $('#audio-notice'); notice.textContent = text; notice.hidden = false; noticeUntil = performance.now() + 3500;
}
function syncSoundButtons() {
  musicButton.textContent = sound.music ? '♪ 声音开' : '♪ 声音关';
  musicButton.setAttribute('aria-pressed', String(sound.music));
  paperButton.textContent = sound.paper ? '纸声开' : '纸声关';
  paperButton.setAttribute('aria-pressed', String(sound.paper));
}
function playNote(id: MaterialId) { pulse = id; pulseStart = sound.note(id); }
async function unlockSound() {
  const epoch = lifecycleEpoch;
  const enabled = await sound.unlock();
  if (epoch !== lifecycleEpoch || document.hidden || failure) { void sound.suspend(); return false; }
  return enabled;
}
async function enableSound() {
  const request = ++audioRequest;
  const enabled = await unlockSound();
  if (request !== audioRequest) return false;
  sound.music = enabled; syncSoundButtons();
  if (!enabled) notify('声音暂时无法开启，你仍可以无声体验。');
  return enabled;
}
function startDemo() { sound.stop(); demoTime = 0; demoIndex = -1; playingDemo = true; }
function dispatch(action: Action) {
  const before = game;
  game = act(game, action);
  if (game.phase !== before.phase || game.run !== before.run) {
    phaseTime = 0; pulse = null; playingDemo = false; sound.stop();
    if (game.phase === 'demo') startDemo();
    if (game.phase === 'challenge' || game.phase === 'intro') sound.page();
  }
  if (paused(game) && !paused(before)) { sound.stop(); pulse = null; }
  if (game.help !== before.help && !game.suspended && !game.portrait) sound.page();
  if (action.type === 'select' && isInteractive() && game.selected) playNote(game.selected);
  if (action.type === 'submit' && game.result !== 'empty' && game.selected && !paused(game)) playNote(game.selected);
  updateUI();
}
function showOverlay(key: string, html: string) {
  if (key === previousOverlay) return;
  previousOverlay = key;
  if (key) {
    if (overlay.hidden) returnFocus = document.activeElement as HTMLElement;
    world.inert = true; overlay.hidden = false;
    overlay.querySelector('.modal-paper')!.innerHTML = html;
    overlay.querySelector<HTMLElement>('button:not(:disabled)')?.focus();
  } else {
    overlay.hidden = true; world.inert = false;
    if (returnFocus?.isConnected && !(returnFocus as HTMLButtonElement).disabled) returnFocus.focus();
  }
}
function updateUI() {
  world.dataset.phase = game.phase; world.dataset.run = String(game.run);
  world.dataset.assisted = String(game.helpUsed);
  world.dataset.paused = String(paused(game));
  const phase = game.phase;
  const stage = ['arrival', 'approach', 'intro'].includes(phase) ? 0 : ['demo', 'practice'].includes(phase) ? 1 : phase === 'complete' ? 3 : 2;
  $('#chapter-label').textContent = ['初见 · 声音之桥', '试试 · 音符有名字', '出发 · 让机关响起来', '抵达 · 桥的另一边'][stage];
  document.querySelectorAll('.steps i').forEach((dot, i) => dot.classList.toggle('active', i <= stage));
  helpButton.hidden = !['practice', 'challenge', 'bridge', 'crossing', 'complete'].includes(phase);
  const panelKey = `${phase}:${game.practiceDone}`;
  if (panelKey !== previousPanel) {
    previousPanel = panelKey;
    let html = '';
    if (phase === 'arrival' || phase === 'approach') html = `<span class="eyebrow">声音之桥 / 01</span><h1 id="lesson-title">给花园<br>一个声音。</h1><p>小拍的路，被一座安静的桥挡住了。<br>走近机关，看看它需要什么。</p><div class="sketch-divider">· · ♪ · ·</div><p class="hint">${phase === 'approach' ? '小拍正在靠近…' : '轻点右边的机关，开始这段冒险。'}</p>`;
    if (phase === 'intro') html = `<span class="eyebrow">认识一个小秘密</span><h1 id="lesson-title">声音，也有名字。</h1>${explanation}<div class="actions">${button('listen', '听听看 →')}${button('silent', '无声继续', true)}</div>`;
    if (phase === 'demo') html = `<span class="eyebrow">看看，也听听</span><h1 id="lesson-title">三个名字，三个音。</h1><p>发声时，对应的材料会亮起来。<br>你也可以单独点一个音，再听一次。</p><div class="note-row"><button data-note="C">C</button><button data-note="D">D</button><button data-note="E">E</button></div><div class="actions">${button('practice', '我来试试 →')}${button('demo', '再听一遍', true)}</div>`;
    if (phase === 'practice') html = `<span class="eyebrow">一起试一次</span><h1 id="lesson-title">${game.practiceDone ? '就是这个声音！' : '把 C 交给机关。'}</h1><p>${game.practiceDone ? '你找到了 C。收起说明，试着自己唤醒这座桥。' : '先点标着 C 的材料，再点机关的圆槽。<br>选错也没关系，换一枚再试试。'}</p>${game.practiceDone ? button('challenge', '收起说明，开始挑战 →') : '<div class="mini-rule"><span>C</span><b>→</b><span class="slot-symbol">○</span></div>'}`;
    if (phase === 'challenge') html = `<span class="eyebrow">轮到你了</span><h1 id="lesson-title">唤醒声音之桥</h1><div class="target"><small>机关需要</small><strong>C</strong></div>`;
    if (phase === 'complete') html = `<span class="eyebrow">声音，真的起作用了</span><h1 id="lesson-title">路，打开了。</h1><p>一个 C，让安静的机关转了起来。<br>小拍已经抵达桥的另一边。</p><p class="completion">${game.helpUsed ? '借助回看，完成了这次尝试。' : '你独立完成了这次尝试。'}</p>${button('replay', '再玩一次 ↻')}`;
    lesson.classList.toggle('task-card', phase === 'challenge');
    lesson.innerHTML = html; lesson.hidden = !html;
    lesson.getAnimations().forEach(animation => animation.cancel());
    if (html && !reduced.matches) lesson.animate(
      [{ opacity: 0, translate: '-10px 0', scale: '.97 1' }, { opacity: 1, translate: '0 0', scale: '1 1' }],
      { duration: 220, easing: 'ease-out' },
    );
  }
  const resultMessage = game.result === 'wrong' ? `这枚是 ${game.selected}。机关需要 C，可以换一枚再试。` : game.result === 'empty' ? '先选一枚材料，再点机关的圆槽。' : '';
  $('#feedback').textContent = resultMessage || ({ arrival: '轻点机关，小拍会自己走过去。', approach: '哒、哒、哒…', intro: '先认识声音，再让声音改变花园。', demo: sound.music ? '听声音，也看材料上的名字。' : '无声模式 · 跟着亮起的材料认识它的名字。', practice: game.practiceDone ? '练习完成 · 准备独立试一次' : game.selected ? `已选 ${game.selected} · 再点机关的圆槽` : '点选材料 → 点圆槽放入', challenge: game.selected ? `已选 ${game.selected} · 点机关的圆槽试一试` : '三枚材料，一个声音。你来决定。', bridge: '咔嗒——机关听见了。', crossing: '桥已经稳稳落下，小拍出发了。', complete: '下次再见，声音探险家。' } as Record<Phase, string>)[phase];
  $('#feedback').classList.toggle('retry', game.result === 'wrong');
  materials.forEach(b => {
    b.disabled = !isInteractive(); b.hidden = !['practice', 'challenge'].includes(phase) || game.practiceDone && phase === 'practice';
    b.setAttribute('aria-pressed', String(game.selected === b.dataset.material));
  });
  slot.disabled = !(phase === 'arrival' || isInteractive()) || paused(game) || !!failure;
  slot.hidden = !['arrival', 'practice', 'challenge'].includes(phase) || (phase === 'practice' && game.practiceDone);
  slot.setAttribute('aria-label', phase === 'arrival' ? '靠近机关' : '将选中材料放入机关');
  slot.classList.toggle('arrival', phase === 'arrival');
  if (failure) showOverlay('error', `<span class="eyebrow">花园暂时停下了</span><h2 id="overlay-title">画面需要重新开启</h2><p>${failure}</p><p>重新加载会从头开始这次体验。</p>${button('reload', '重新加载')}`);
  else if (game.suspended) showOverlay(`suspend:${game.portrait}`, `<span class="eyebrow">小拍在等你</span><h2 id="overlay-title">准备好，就继续吧。</h2><p>${game.portrait ? '请先把手机转成横屏。' : '花园停在你离开的位置，声音也暂停了。'}</p><button class="primary" data-action="resume" ${game.portrait ? 'disabled' : ''}>继续这次冒险 →</button>`);
  else if (game.portrait) showOverlay('portrait', `<span class="eyebrow">给花园多一点空间</span><h2 id="overlay-title">横过来，去冒险。</h2><div class="rotate" aria-hidden="true">▯ ↻ ▭</div><p>转动手机，就能看到完整的声音之桥。<br>当前进度会保留。</p>`);
  else if (game.help) showOverlay('help', `<span class="eyebrow">回看 · 音符的名字</span><h2 id="overlay-title">机关在等哪个声音？</h2>${explanation}<p class="hint">关掉说明后，刚才的选择还在。</p>${button('close', '回到花园 →')}`);
  else showOverlay('', '');
}

app.addEventListener('click', async event => {
  const target = (event.target as HTMLElement).closest<HTMLButtonElement>('button');
  if (!target || target.disabled) return;
  if (target === musicButton) {
    if (sound.music) { audioRequest++; sound.music = false; sound.stop(); } else await enableSound();
    syncSoundButtons(); updateUI(); return;
  }
  if (target === paperButton) { sound.paper = !sound.paper; if (sound.paper) void unlockSound(); syncSoundButtons(); return; }
  if (target === helpButton) { dispatch({ type: 'help', open: true }); return; }
  if (target.dataset.material) { dispatch({ type: 'select', id: target.dataset.material as MaterialId }); return; }
  if (target === slot) { if (game.phase === 'arrival' && sound.paper) void unlockSound(); dispatch({ type: game.phase === 'arrival' ? 'approach' : 'submit' }); return; }
  if (target.dataset.note) { playingDemo = false; playNote(target.dataset.note as MaterialId); return; }
  switch (target.dataset.action) {
    case 'listen': {
      const run = game.run;
      await enableSound();
      if (game.run === run && game.phase === 'intro' && !paused(game)) dispatch({ type: 'next' });
      break;
    }
    case 'silent': audioRequest++; sound.music = false; sound.paper = false; sound.stop(); syncSoundButtons(); dispatch({ type: 'next' }); break;
    case 'practice': dispatch({ type: 'next' }); break;
    case 'demo': startDemo(); break;
    case 'challenge': dispatch({ type: 'enterChallenge' }); break;
    case 'close': dispatch({ type: 'help', open: false }); break;
    case 'resume': {
      if (document.hidden || game.portrait) return;
      const epoch = lifecycleEpoch;
      if (sound.music || sound.paper) await unlockSound();
      if (epoch === lifecycleEpoch && !document.hidden && !game.portrait) dispatch({ type: 'resume' });
      break;
    }
    case 'replay': dispatch({ type: 'replay' }); break;
    case 'reload': window.location.reload(); break;
  }
});
// Native buttons provide keyboard activation. Cancelled touch gestures must never synthesize a submission.
let cancelledPointer = false;
app.addEventListener('pointerdown', () => { cancelledPointer = false; }, true);
app.addEventListener('pointercancel', () => { cancelledPointer = true; }, true);
app.addEventListener('click', event => { if (cancelledPointer) { event.preventDefault(); event.stopImmediatePropagation(); cancelledPointer = false; } }, true);
app.addEventListener('keydown', event => {
  cancelledPointer = false;
  if (overlay.hidden) return;
  if (event.key === 'Escape' && game.help && !game.suspended && !game.portrait) dispatch({ type: 'help', open: false });
  if (event.key === 'Tab') {
    const buttons = Array.from(overlay.querySelectorAll<HTMLButtonElement>('button:not(:disabled)'));
    if (!buttons.length) { event.preventDefault(); return; }
    const index = buttons.indexOf(document.activeElement as HTMLButtonElement);
    if (event.shiftKey && index <= 0) { buttons.at(-1)!.focus(); event.preventDefault(); }
    else if (!event.shiftKey && index === buttons.length - 1) { buttons[0].focus(); event.preventDefault(); }
  }
});
document.addEventListener('visibilitychange', () => {
  if (document.hidden) { lifecycleEpoch++; audioRequest++; dispatch({ type: 'suspend' }); void sound.suspend(); }
});
window.addEventListener('pagehide', () => { lifecycleEpoch++; audioRequest++; dispatch({ type: 'suspend' }); void sound.suspend(); });
canvas.addEventListener('webglcontextlost', event => { event.preventDefault(); fail('画面连接中断了。请重新加载花园。'); });
function fail(message: string) { failure = message; void sound.suspend(); updateUI(); }
function resize() {
  const { width, height } = world.getBoundingClientRect();
  scene?.resize(width, height);
  dispatch({ type: 'portrait', value: height > width });
}
try { scene = createScene(canvas); } catch (error) { console.error(error); fail('当前浏览器无法绘制这座花园。请检查浏览器是否支持 WebGL 2。'); }
new ResizeObserver(resize).observe(world);
window.visualViewport?.addEventListener('resize', resize);
resize(); syncSoundButtons(); updateUI();

function frame(now: number) {
  requestAnimationFrame(frame);
  const dt = lastTime ? Math.min((now - lastTime) / 1000, 0.05) : 0;
  lastTime = now;
  if (failure || !scene) return;
  const running = !paused(game);
  if (running) {
    phaseTime += dt; totalTime += dt;
    if (playingDemo) {
      demoTime += dt;
      const index = Math.floor(demoTime / 0.95);
      if (index < 3 && index !== demoIndex) { demoIndex = index; playNote((['C', 'D', 'E'] as MaterialId[])[index]); }
      if (index >= 3) playingDemo = false;
    }
  }
  const progress = reduced.matches ? 1 : Math.min(phaseTime / (duration[game.phase] || 1), 1);
  const activePulse = pulse && running && now >= pulseStart && now < pulseStart + 600 ? pulse : null;
  scene.render({
    approach: game.phase === 'arrival' ? 0 : game.phase === 'approach' ? progress : 1,
    bridge: game.phase === 'bridge' ? progress : ['crossing', 'complete'].includes(game.phase) ? 1 : 0,
    travel: game.phase === 'crossing' ? progress : game.phase === 'complete' ? 1 : 0,
    selected: game.selected, installed: ['bridge', 'crossing', 'complete'].includes(game.phase),
    order: ['challenge', 'bridge', 'crossing', 'complete'].includes(game.phase) ? ['E', 'C', 'D'] : ['C', 'D', 'E'],
    pulse: activePulse, time: totalTime,
  });
  const anchors = scene.anchors();
  for (const target of [...materials, slot]) {
    const position = anchors[target === slot ? 'slot' : target.dataset.material as MaterialId];
    target.style.left = `${position.x * 100}%`; target.style.top = `${position.y * 100}%`;
  }
  document.querySelectorAll<HTMLButtonElement>('[data-note]').forEach(b => b.classList.toggle('sounding', b.dataset.note === activePulse));
  if (running && progress === 1) {
    const finished = { approach: 'arrived', bridge: 'bridgeReady', crossing: 'exitReached' } as const;
    if (game.phase in finished) dispatch({ type: finished[game.phase as keyof typeof finished], run: game.run });
  }
  if (noticeUntil && now > noticeUntil) { $('#audio-notice').hidden = true; noticeUntil = 0; }
}
requestAnimationFrame(frame);
if (import.meta.hot) import.meta.hot.dispose(() => { scene?.dispose(); void sound.suspend(); });
