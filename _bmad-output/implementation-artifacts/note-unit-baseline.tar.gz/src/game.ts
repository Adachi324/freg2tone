export type MaterialId = 'C' | 'D' | 'E';
export type Phase = 'arrival' | 'approach' | 'intro' | 'demo' | 'practice' | 'challenge' | 'bridge' | 'crossing' | 'complete';
export type Game = {
  phase: Phase; run: number; selected: MaterialId | null;
  help: boolean; helpUsed: boolean; portrait: boolean; suspended: boolean;
  result: 'wrong' | 'right' | 'empty' | null; practiceDone: boolean;
};
export type Action =
  | { type: 'approach' | 'next' | 'submit' | 'enterChallenge' | 'suspend' | 'resume' | 'replay' }
  | { type: 'arrived' | 'bridgeReady' | 'exitReached'; run: number }
  | { type: 'select'; id: MaterialId }
  | { type: 'help'; open: boolean }
  | { type: 'portrait'; value: boolean };
export function createGame(): Game {
  return { phase: 'arrival', run: 1, selected: null, result: null, practiceDone: false, help: false, helpUsed: false, portrait: false, suspended: false };
}
export function paused(g: Game): boolean { return g.help || g.portrait || g.suspended; }
export function act(game: Game, action: Action): Game {
  const g = { ...game };
  if (action.type === 'portrait') return { ...g, portrait: action.value };
  if (action.type === 'suspend') return { ...g, suspended: true };
  if (action.type === 'resume') return g.portrait ? g : { ...g, suspended: false };
  if (action.type === 'help' && !g.suspended && !g.portrait) {
    if (!['practice', 'challenge', 'bridge', 'crossing', 'complete'].includes(g.phase)) return g;
    return { ...g, help: action.open, helpUsed: g.helpUsed || (action.open && g.phase === 'challenge') };
  }
  if (paused(g)) return g;
  if (action.type === 'replay' && g.phase === 'complete') return { ...createGame(), run: g.run + 1 };
  if (action.type === 'approach' && g.phase === 'arrival') g.phase = 'approach';
  if (action.type === 'arrived' && action.run === g.run && g.phase === 'approach') g.phase = 'intro';
  if (action.type === 'next') {
    if (g.phase === 'intro') g.phase = 'demo';
    else if (g.phase === 'demo') g.phase = 'practice';
  }
  if (action.type === 'select' && (g.phase === 'challenge' || (g.phase === 'practice' && !g.practiceDone))) {
    g.selected = g.selected === action.id ? null : action.id;
    g.result = null;
  }
  if (action.type === 'submit' && (g.phase === 'challenge' || (g.phase === 'practice' && !g.practiceDone))) {
    g.result = g.selected === null ? 'empty' : g.selected === 'C' ? 'right' : 'wrong';
    if (g.phase === 'practice') g.practiceDone = g.result === 'right';
    else if (g.result === 'right') g.phase = 'bridge';
  }
  if (action.type === 'enterChallenge' && g.phase === 'practice' && g.practiceDone) {
    g.phase = 'challenge'; g.selected = null; g.result = null;
  }
  if ('run' in action && action.run === g.run) {
    if (action.type === 'bridgeReady' && g.phase === 'bridge') g.phase = 'crossing';
    if (action.type === 'exitReached' && g.phase === 'crossing') g.phase = 'complete';
  }
  return g;
}
