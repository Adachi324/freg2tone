import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createGame, act } from '../src/game.ts';

test('玩家先靠近机关，才能读说明并亲手练习；错误材料不开桥', () => {
  let game = createGame();
  game = act(game, { type: 'approach' });
  game = act(game, { type: 'arrived', run: game.run });
  game = act(game, { type: 'next' });
  game = act(game, { type: 'next' });
  assert.equal(game.phase, 'practice');
  game = act(game, { type: 'select', id: 'D' });
  game = act(game, { type: 'submit' });
  assert.equal(game.phase, 'practice');
  assert.equal(game.result, 'wrong');
  assert.equal(game.practiceDone, false);
});

function practice() {
  let g = createGame();
  for (const a of [{ type: 'approach' }, { type: 'arrived', run: 1 }, { type: 'next' }, { type: 'next' }] as const) g = act(g, a);
  return g;
}
function challenge() {
  let g = practice();
  g = act(g, { type: 'select', id: 'C' });
  g = act(g, { type: 'submit' });
  g = act(g, { type: 'enterChallenge' });
  return g;
}
test('练习正确后直接进入挑战并清空选择；桥打开后才让角色通过', () => {
  let g = practice();
  assert.equal(act(g, { type: 'enterChallenge' }).phase, 'practice');
  g = act(g, { type: 'select', id: 'C' });
  g = act(g, { type: 'submit' });
  g = act(g, { type: 'enterChallenge' });
  assert.equal(g.phase, 'challenge');
  assert.equal(g.selected, null);
  assert.equal(g.result, null);
  assert.equal(act(g, { type: 'submit' }).result, 'empty');
  g = act(g, { type: 'select', id: 'D' });
  g = act(g, { type: 'submit' });
  assert.equal(g.phase, 'challenge');
  g = act(g, { type: 'select', id: 'C' });
  g = act(g, { type: 'submit' });
  assert.equal(g.phase, 'bridge');
  assert.equal(act(g, { type: 'exitReached', run: g.run }).phase, 'bridge');
  assert.deepEqual(act(g, { type: 'submit' }), g);
  g = act(g, { type: 'bridgeReady', run: g.run });
  assert.equal(g.phase, 'crossing');
  g = act(g, { type: 'exitReached', run: g.run });
  assert.equal(g.phase, 'complete');
});

test('帮助/竖屏/后台互不覆盖；关闭帮助保留选择并标记辅助', () => {
  let g = act(challenge(), { type: 'select', id: 'D' });
  g = act(g, { type: 'help', open: true });
  g = act(g, { type: 'portrait', value: true });
  g = act(g, { type: 'suspend' });
  assert.equal(act(g, { type: 'submit' }).result, null);
  g = act(g, { type: 'resume' });
  assert.equal(g.suspended, true);
  g = act(g, { type: 'portrait', value: false });
  g = act(g, { type: 'resume' });
  assert.equal(g.help, true);
  assert.equal(act(g, { type: 'select', id: 'C' }).selected, 'D');
  g = act(g, { type: 'help', open: false });
  assert.equal(g.selected, 'D');
  assert.equal(g.helpUsed, true);
  assert.equal(act(g, { type: 'submit' }).result, 'wrong');
});

test('完整复玩使旧动画回调失效，清除提示记录；暂停时动画不能推进', () => {
  let g = challenge();
  g = act(g, { type: 'select', id: 'C' });
  g = act(g, { type: 'submit' });
  g = act(g, { type: 'suspend' });
  assert.equal(act(g, { type: 'bridgeReady', run: 1 }).phase, 'bridge');
  g = act(g, { type: 'resume' });
  g = act(g, { type: 'bridgeReady', run: 1 });
  g = act(g, { type: 'exitReached', run: 1 });
  g = act(g, { type: 'replay' });
  assert.equal(g.phase, 'arrival');
  assert.equal(g.run, 2);
  assert.equal(g.helpUsed, false);
  g = act(g, { type: 'approach' });
  assert.equal(act(g, { type: 'arrived', run: 1 }).phase, 'approach');
  assert.equal(act(g, { type: 'arrived', run: 2 }).phase, 'intro');
});

test('未选材料不提交，同一材料再点取消，失败可直接替换', () => {
  let g = challenge();
  assert.equal(act(g, { type: 'submit' }).result, 'empty');
  g = act(g, { type: 'select', id: 'D' });
  g = act(g, { type: 'select', id: 'D' });
  assert.equal(g.selected, null);
  g = act(g, { type: 'select', id: 'E' });
  g = act(g, { type: 'submit' });
  assert.equal(g.result, 'wrong');
  g = act(g, { type: 'select', id: 'C' });
  assert.equal(g.selected, 'C');
  assert.equal(act(g, { type: 'submit' }).phase, 'bridge');
});

test('通关之后回看说明不追溯修改独立完成记录', () => {
  let g=challenge();
  g=act(g,{type:'select',id:'C'}); g=act(g,{type:'submit'});
  g=act(g,{type:'bridgeReady',run:g.run}); g=act(g,{type:'exitReached',run:g.run});
  g=act(g,{type:'help',open:true});
  assert.equal(g.helpUsed,false);
});
