import { test, expect, type Page } from '@playwright/test';
async function start(page: Page) {
  await page.goto('/');
  await page.getByRole('button', { name: '靠近机关', exact: true }).click();
  await page.getByRole('button', { name: '无声继续', exact: true }).click();
  await page.getByRole('button', { name: '我来试试 →', exact: true }).click();
}
async function challenge(page: Page) {
  await start(page);
  await page.getByRole('button', { name: '选择材料 C', exact: true }).click();
  await page.getByRole('button', { name: '将选中材料放入机关', exact: true }).click();
  await page.getByRole('button', { name: '收起说明，开始挑战 →', exact: true }).click();
  await expect(page.locator('#world')).toHaveAttribute('data-phase', 'challenge');
}
async function complete(page: Page) {
  await page.getByRole('button', { name: '选择材料 C', exact: true }).click();
  await page.getByRole('button', { name: '将选中材料放入机关', exact: true }).click();
  await expect(page.locator('#world')).toHaveAttribute('data-phase', 'complete');
}

test('完整可玩流程、失败替换、回看不穿透、复玩及运行无错误', async ({ page }) => {
  const errors: string[] = [];
  page.on('pageerror', e => errors.push(e.message));
  page.on('console', m => { if (m.type() === 'error') errors.push(m.text()); });
  await challenge(page);
  await page.screenshot({ path: '../_bmad-output/implementation-artifacts/probe-v2-challenge.png' });
  await page.getByRole('button', { name: '选择材料 D', exact: true }).click();
  await page.getByRole('button', { name: '将选中材料放入机关', exact: true }).click();
  await expect(page.locator('#feedback')).toContainText('这枚是 D');
  await page.getByRole('button', { name: '回看', exact: true }).click();
  await expect(page.getByRole('dialog')).toBeVisible();
  await page.getByRole('button', { name: '回到花园 →', exact: true }).click();
  await expect(page.getByRole('button', { name: '选择材料 D', exact: true })).toHaveAttribute('aria-pressed', 'true');
  await complete(page);
  await expect(page.locator('.completion')).toContainText('借助回看');
  await page.screenshot({ path: '../_bmad-output/implementation-artifacts/probe-v2-complete.png' });
  await page.getByRole('button', { name: '再玩一次 ↻', exact: true }).click();
  await expect(page.locator('#world')).toHaveAttribute('data-phase', 'arrival');
  await expect(page.locator('#world')).toHaveAttribute('data-assisted', 'false');
  expect(errors).toEqual([]);
});

test('横竖屏与后台覆盖保留原尝试；减少动效完成相同结果', async ({ page }) => {
  await page.emulateMedia({ reducedMotion: 'reduce' });
  await challenge(page);
  await page.getByRole('button', { name: '选择材料 E', exact: true }).click();
  await page.getByRole('button', { name: '回看', exact: true }).click();
  await page.setViewportSize({ width: 430, height: 932 });
  await expect(page.getByText('横过来，去冒险。')).toBeVisible();
  await page.evaluate(() => window.dispatchEvent(new Event('pagehide')));
  await page.setViewportSize({ width: 932, height: 430 });
  await page.getByRole('button', { name: '继续这次冒险 →' }).click();
  await expect(page.getByText('机关在等哪个声音？')).toBeVisible();
  await page.getByRole('button', { name: '回到花园 →' }).click();
  await expect(page.getByRole('button', { name: '选择材料 E', exact: true })).toHaveAttribute('aria-pressed', 'true');
  await complete(page);
});

test('触控命中区不重叠且不少于44px，教程/材料在实际视口中可达', async ({ page }) => {
  for (const size of [{width:932,height:430},{width:844,height:390},{width:667,height:375},{width:1366,height:768}]) {
    await page.setViewportSize(size);
    await challenge(page);
    const boxes = await page.locator('button.hotspot:visible').evaluateAll(els => els.map(e => {
      const r = e.getBoundingClientRect(); return {x:r.x,y:r.y,w:r.width,h:r.height};
    }));
    for (let i = 0; i < boxes.length; i++) {
      const a = boxes[i];
      expect(a.w).toBeGreaterThanOrEqual(44); expect(a.h).toBeGreaterThanOrEqual(44);
      expect(a.x).toBeGreaterThanOrEqual(0); expect(a.x+a.w).toBeLessThanOrEqual(size.width);
      for (const b of boxes.slice(i+1)) expect(a.x+a.w <= b.x || b.x+b.w <= a.x || a.y+a.h <= b.y || b.y+b.h <= a.y, JSON.stringify({size,a,b})).toBeTruthy();
    }
  }
});

test('声音可开启关闭；WebGL context丢失有重载入口', async ({ page }) => {
  await page.goto('/');
  await page.getByRole('button', {name:'♪ 声音关',exact:true}).click();
  await expect(page.locator('#music')).toHaveAttribute('aria-pressed','true');
  await page.getByRole('button', {name:'♪ 声音开',exact:true}).click();
  await expect(page.locator('#music')).toHaveAttribute('aria-pressed','false');
  await page.locator('#scene').evaluate(canvas => canvas.dispatchEvent(new Event('webglcontextlost', {cancelable:true})));
  await expect(page.getByRole('button', {name:'重新加载',exact:true})).toBeVisible();
});

test('无音频设备时仍能无声完成；初始化渲染失败可重试', async ({ page }) => {
  await page.addInitScript(() => {
    window.AudioContext = class { constructor() { throw new Error('test: audio unavailable'); } } as unknown as typeof AudioContext;
  });
  await page.goto('/');
  await page.getByRole('button', {name:'♪ 声音关',exact:true}).click();
  await expect(page.getByText('声音暂时无法开启，你仍可以无声体验。')).toBeVisible();
  await page.emulateMedia({ reducedMotion: 'reduce' });
  await challenge(page); await complete(page);
  await page.addInitScript(() => {
    const original = HTMLCanvasElement.prototype.getContext;
    HTMLCanvasElement.prototype.getContext = function (this: HTMLCanvasElement, ...args: Parameters<typeof original>) {
      if (String(args[0]).startsWith('webgl')) return null;
      return original.apply(this,args);
    } as typeof original;
  });
  await page.goto('/');
  await expect(page.getByRole('button', {name:'重新加载',exact:true})).toBeVisible();
  await expect(page.getByText('当前浏览器无法绘制这座花园。请检查浏览器是否支持 WebGL 2。')).toBeVisible();
});

test('连续20轮错误重试和复玩，5次恢复，无重复通行或串状态', async ({ page }) => {
  test.setTimeout(120000);
  await page.emulateMedia({ reducedMotion: 'reduce' });
  await page.goto('/');
  for (let i=1; i<=20; i++) {
    await page.getByRole('button', {name:'靠近机关',exact:true}).click();
    await page.getByRole('button', {name:'无声继续',exact:true}).click();
    await page.getByRole('button', {name:'我来试试 →',exact:true}).click();
    await page.getByRole('button', {name:'选择材料 C',exact:true}).click();
    await page.getByRole('button', {name:'将选中材料放入机关',exact:true}).click();
    await page.getByRole('button', {name:'收起说明，开始挑战 →',exact:true}).click();
    await expect(page.locator('#world')).toHaveAttribute('data-phase','challenge');
    await page.getByRole('button', {name:'选择材料 D',exact:true}).click();
    await page.getByRole('button', {name:'将选中材料放入机关',exact:true}).click();
    await expect(page.locator('#feedback')).toContainText('这枚是 D');
    if (i<=5) {
      await page.evaluate(() => window.dispatchEvent(new Event('pagehide')));
      await page.getByRole('button', {name:'继续这次冒险 →'}).click();
      await expect(page.getByRole('button', {name:'选择材料 D',exact:true})).toHaveAttribute('aria-pressed','true');
    }
    await complete(page);
    await expect(page.locator('#world')).toHaveAttribute('data-run',String(i));
    await page.getByRole('button', {name:'再玩一次 ↻',exact:true}).click();
  }
});

test('触摸取消不提交；收起说明后直接可操作，暂停桥动作后可继续且不抢跑', async ({ page }) => {
  await start(page);
  await page.getByRole('button', {name:'选择材料 C',exact:true}).click();
  const slot=page.getByRole('button', {name:'将选中材料放入机关',exact:true});
  await slot.dispatchEvent('pointercancel');
  await slot.dispatchEvent('click');
  await expect(page.locator('#world')).toHaveAttribute('data-phase','practice');
  await expect(page.getByRole('button', {name:'收起说明，开始挑战 →',exact:true})).toHaveCount(0);
  await slot.click();
  await page.getByRole('button', {name:'收起说明，开始挑战 →',exact:true}).click();
  await page.evaluate(() => window.dispatchEvent(new Event('pagehide')));
  await expect(page.locator('#world')).toHaveAttribute('data-phase','challenge');
  await expect(page.locator('#world')).toHaveAttribute('data-paused','true');
  await page.getByRole('button', {name:'继续这次冒险 →'}).click();
  await expect(page.locator('#world')).toHaveAttribute('data-phase','challenge');
  await page.getByRole('button', {name:'选择材料 C',exact:true}).click();
  await slot.click();
  await page.evaluate(() => window.dispatchEvent(new Event('pagehide')));
  await page.waitForTimeout(1500);
  await expect(page.locator('#world')).toHaveAttribute('data-phase','bridge');
  await page.getByRole('button', {name:'继续这次冒险 →'}).click();
  await expect(page.locator('#world')).toHaveAttribute('data-phase','complete');
});

test('真实Web Audio解锁与暂停：隐藏期间不产生新声，回来不补播旧音', async ({ page }) => {
  await page.addInitScript(() => {
    const Native = window.AudioContext;
    const observed = { contexts: [] as AudioContext[], starts: 0 };
    (window as unknown as { audioObserved: typeof observed }).audioObserved = observed;
    window.AudioContext = class extends Native {
      constructor(...args: ConstructorParameters<typeof Native>) {
        super(...args); observed.contexts.push(this);
      }
      createOscillator() {
        const oscillator = super.createOscillator(); const start = oscillator.start.bind(oscillator);
        oscillator.start = (...args: Parameters<typeof start>) => { observed.starts++; start(...args); };
        return oscillator;
      }
    };
  });
  const audioState = () => page.evaluate(() => {
    const o=(window as unknown as {audioObserved:{contexts:AudioContext[];starts:number}}).audioObserved;
    return { state:o.contexts[0]?.state, starts:o.starts };
  });
  await challenge(page);
  await page.getByRole('button',{name:'♪ 声音关',exact:true}).click();
  await page.getByRole('button',{name:'选择材料 D',exact:true}).click();
  const before=await audioState(); expect(before.state).toBe('running'); expect(before.starts).toBeGreaterThan(0);
  await page.evaluate(() => window.dispatchEvent(new Event('pagehide')));
  await expect.poll(async()=> (await audioState()).state).toBe('suspended');
  await page.waitForTimeout(250);
  expect((await audioState()).starts).toBe(before.starts);
  await page.getByRole('button',{name:'继续这次冒险 →'}).click();
  await expect.poll(async()=> (await audioState()).state).toBe('running');
  expect((await audioState()).starts).toBe(before.starts);
  await page.getByRole('button',{name:'选择材料 E',exact:true}).click();
  expect((await audioState()).starts).toBeGreaterThan(before.starts);
});

test('资源脚本加载失败时提供独立于主模块的重试入口', async ({ page }) => {
  await page.route('**/assets/*.js', route => route.abort('failed')); await page.goto('/');
  await expect(page.getByRole('button',{name:'重新加载',exact:true})).toBeVisible();
});

test('仅开纸声也能解锁，后台回来保持纸声开且音符关', async ({ page }) => {
  await page.addInitScript(() => {
    const Native = window.AudioContext; const o = { contexts:[] as AudioContext[], pages:0 };
    (window as unknown as {paperObserved:typeof o}).paperObserved=o;
    window.AudioContext=class extends Native {
      constructor(...args:ConstructorParameters<typeof Native>){super(...args);o.contexts.push(this);}
      createBufferSource(){ const source=super.createBufferSource(); const start=source.start.bind(source);
        source.start=(...args:Parameters<typeof start>)=>{o.pages++;start(...args);};return source; }
    };
  });
  await page.goto('/'); await page.getByRole('button',{name:'靠近机关',exact:true}).click();
  await page.getByRole('button',{name:'听听看 →',exact:true}).waitFor();
  await page.evaluate(()=>window.dispatchEvent(new Event('pagehide')));
  await page.getByRole('button',{name:'继续这次冒险 →'}).click();
  await expect(page.locator('#world')).toHaveAttribute('data-paused','false');
  const output=await page.evaluate(()=>{const o=(window as unknown as {paperObserved:{contexts:AudioContext[];pages:number}}).paperObserved;return{state:o.contexts[0]?.state,pages:o.pages};});
  expect(output.state).toBe('running');expect(output.pages).toBeGreaterThan(0);
  await expect(page.locator('#music')).toHaveAttribute('aria-pressed','false');
  await expect(page.locator('#paper')).toHaveAttribute('aria-pressed','true');
});

test('迟到的音频解锁不覆盖无声选择或跳过示范，迟到的恢复不取消新的暂停', async ({ page }) => {
  await page.addInitScript(()=>{
    const resume=AudioContext.prototype.resume;
    AudioContext.prototype.resume=function(){return resume.call(this).then(()=>new Promise<void>(resolve=>setTimeout(resolve,500)));};
  });
  await page.goto('/'); await page.getByRole('button',{name:'靠近机关',exact:true}).click();
  await page.getByRole('button',{name:'听听看 →',exact:true}).click();
  await page.getByRole('button',{name:'无声继续',exact:true}).click();
  await page.waitForTimeout(650);
  await expect(page.locator('#world')).toHaveAttribute('data-phase','demo');
  await expect(page.locator('#music')).toHaveAttribute('aria-pressed','false');
  await page.getByRole('button',{name:'♪ 声音关',exact:true}).click();
  await expect(page.locator('#music')).toHaveAttribute('aria-pressed','true');
  await page.evaluate(()=>window.dispatchEvent(new Event('pagehide')));
  await page.getByRole('button',{name:'继续这次冒险 →'}).click();
  await page.evaluate(()=>window.dispatchEvent(new Event('pagehide')));
  await page.waitForTimeout(650);
  await expect(page.locator('#world')).toHaveAttribute('data-paused','true');
  await expect(page.getByRole('button',{name:'继续这次冒险 →'})).toBeVisible();
});

test('触摸取消后键盘仍可操作，通关后回看不改变完成记录', async ({ page }) => {
  await page.emulateMedia({reducedMotion:'reduce'}); await challenge(page);
  const c=page.getByRole('button',{name:'选择材料 C',exact:true});
  await c.dispatchEvent('pointercancel'); await c.focus(); await c.press('Enter');
  await expect(c).toHaveAttribute('aria-pressed','true');
  await page.getByRole('button',{name:'将选中材料放入机关',exact:true}).click();
  await expect(page.locator('#world')).toHaveAttribute('data-phase','complete');
  await page.getByRole('button',{name:'回看',exact:true}).click();
  await page.getByRole('button',{name:'回到花园 →',exact:true}).click();
  await expect(page.locator('#world')).toHaveAttribute('data-assisted','false');
  await expect(page.locator('.completion')).toContainText('独立完成');
});

test('真实输出信号包含 C D E 的独立音高，关闭声音后输出归零', async ({ page }) => {
  await page.addInitScript(() => {
    const Native = window.AudioContext;
    const meters = new Map<AudioContext, AnalyserNode>();
    const connect = AudioNode.prototype.connect;
    AudioNode.prototype.connect = function(this:AudioNode, ...args: unknown[]) {
      const meter = meters.get(this.context as AudioContext);
      if (meter && this !== meter && args[0] === this.context.destination) args[0] = meter;
      return Reflect.apply(connect, this, args);
    } as typeof connect;
    window.AudioContext = class extends Native {
      constructor(...args:ConstructorParameters<typeof Native>) {
        super(...args);
        const meter=this.createAnalyser(); meter.fftSize=32768; meter.smoothingTimeConstant=0;
        meter.connect(this.destination); meters.set(this,meter);
        (window as unknown as { sampleSound:()=>{frequency:number;rms:number} }).sampleSound=()=>{
          const spectrum=new Float32Array(meter.frequencyBinCount); meter.getFloatFrequencyData(spectrum);
          const wave=new Float32Array(meter.fftSize); meter.getFloatTimeDomainData(wave);
          let peak=0,level=-Infinity;
          for(let i=1;i<spectrum.length;i++) {
            const hz=i*this.sampleRate/meter.fftSize;
            if(hz>=200 && hz<=400 && spectrum[i]>level){peak=hz;level=spectrum[i];}
          }
          return {frequency:peak,rms:Math.sqrt(wave.reduce((sum,v)=>sum+v*v,0)/wave.length)};
        };
      }
    };
  });
  await page.emulateMedia({reducedMotion:'reduce'}); await challenge(page);
  await page.getByRole('button',{name:'♪ 声音关',exact:true}).click();
  for (const [note,hz] of [['C',261.63],['D',293.66],['E',329.63]] as const) {
    await page.waitForTimeout(800);
    await page.getByRole('button',{name:`选择材料 ${note}`,exact:true}).click();
    await page.waitForTimeout(250);
    const signal=await page.evaluate(()=>(window as unknown as {sampleSound:()=>{frequency:number;rms:number}}).sampleSound());
    expect(signal.rms).toBeGreaterThan(0.005);
    expect(Math.abs(signal.frequency-hz)).toBeLessThan(3);
  }
  await page.getByRole('button',{name:'♪ 声音开',exact:true}).click();
  await page.getByRole('button',{name:'选择材料 C',exact:true}).click();
  await page.waitForTimeout(900);
  const silent=await page.evaluate(()=>(window as unknown as {sampleSound:()=>{rms:number}}).sampleSound());
  expect(silent.rms).toBeLessThan(0.00001);
});
